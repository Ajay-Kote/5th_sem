import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CMR Technical Campus Attendance Tracker',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
      ),
      home: HomePage(),
    );
  }
}

class Subject {
  String name;
  String code;
  String faculty;
  int attended;
  int total;

  Subject({
    required this.name,
    required this.code,
    required this.faculty,
    this.attended = 0,
    this.total = 0,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Subject> subjects = [
    Subject(
      name: 'Design and Analysis of Algorithms',
      code: 'DAA',
      faculty: 'Mr. B P Deepak Kumar (BDK)',
    ),
    Subject(name: 'DevOps', code: 'DPS', faculty: 'Mrs. S. Aparna (SAN)'),
    Subject(name: 'Computer Networks', code: 'CN', faculty: 'DR Srujan Raju'),
    Subject(
      name: 'Professional Elective-I (PPL)',
      code: 'PPL',
      faculty: 'DR.V. Naresh Kumar (VNK)',
    ),
    Subject(
      name: 'Professional Elective-II (CG)',
      code: 'CG',
      faculty: 'Mrs. M. Sireesha (MSS)',
    ),
    Subject(name: 'DevOps Lab', code: 'DPS LAB', faculty: 'Mrs. S. Aparna'),
    Subject(
      name: 'Computer Networks Lab',
      code: 'CN LAB',
      faculty: 'Mrs T Vasavi',
    ),
    Subject(
      name: 'Advanced English Communication Skills Lab',
      code: 'AECS LAB',
      faculty: 'Ruby Bhatia (RBT)',
    ),
    Subject(
      name: 'UI design- Flutter',
      code: 'FLUTTER LAB',
      faculty: 'Mr. Praveen Kumar',
    ),
    Subject(
      name: 'Intellectual Property Rights',
      code: 'IPR',
      faculty: 'Miss. Siddamma (SDM)',
    ),
  ];

  @override
  void initState() {
    super.initState();
    loadData();
  }

  void markAttendance(int index, bool present) {
    setState(() {
      subjects[index].total += 1;
      if (present) subjects[index].attended += 1;
    });
    saveData();
  }

  double calculatePercentage(Subject s) {
    if (s.total == 0) return 0.0;
    return (s.attended / s.total) * 100;
  }

  double calculateOverallAttendance() {
    int totalAttended = 0;
    int totalClasses = 0;

    for (var subject in subjects) {
      totalAttended += subject.attended;
      totalClasses += subject.total;
    }

    if (totalClasses == 0) return 0.0;
    return (totalAttended / totalClasses) * 100;
  }

  int getClassesNeededFor75() {
    int totalAttended = 0;
    int totalClasses = 0;

    for (var subject in subjects) {
      totalAttended += subject.attended;
      totalClasses += subject.total;
    }

    if (totalClasses == 0) return 0;
    double currentPercentage = (totalAttended / totalClasses) * 100;
    if (currentPercentage >= 75.0) return 0;

    return ((75.0 * totalClasses - totalAttended * 100) / 25).ceil();
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    for (int i = 0; i < subjects.length; i++) {
      prefs.setInt('attended_$i', subjects[i].attended);
      prefs.setInt('total_$i', subjects[i].total);
    }
  }

  Future<void> loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      for (int i = 0; i < subjects.length; i++) {
        subjects[i].attended = prefs.getInt('attended_$i') ?? 0;
        subjects[i].total = prefs.getInt('total_$i') ?? 0;
      }
    });
  }

  void resetData() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Reset All Data'),
        content: Text(
          'Are you sure you want to reset all attendance data? This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                for (var s in subjects) {
                  s.attended = 0;
                  s.total = 0;
                }
              });
              saveData();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('All attendance data has been reset')),
              );
            },
            child: Text('Reset', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void addSubject() {
    TextEditingController nameController = TextEditingController();
    TextEditingController codeController = TextEditingController();
    TextEditingController facultyController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Add New Subject'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                hintText: 'Subject Name',
                labelText: 'Subject Name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: codeController,
              decoration: InputDecoration(
                hintText: 'Subject Code',
                labelText: 'Subject Code',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: facultyController,
              decoration: InputDecoration(
                hintText: 'Faculty Name',
                labelText: 'Faculty Name',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (nameController.text.isNotEmpty &&
                  codeController.text.isNotEmpty &&
                  facultyController.text.isNotEmpty) {
                setState(() {
                  subjects.add(
                    Subject(
                      name: nameController.text,
                      code: codeController.text,
                      faculty: facultyController.text,
                    ),
                  );
                });
                saveData();
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Subject added successfully')),
                );
              }
            },
            child: Text('Add'),
          ),
        ],
      ),
    );
  }

  void deleteSubject(int index) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Delete Subject'),
        content: Text(
          'Are you sure you want to delete "${subjects[index].name}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                subjects.removeAt(index);
              });
              saveData();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Subject deleted successfully')),
              );
            },
            child: Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Color getPercentageColor(double p) {
    if (p >= 75) return Colors.green;
    if (p >= 60) return Colors.orange;
    return Colors.red;
  }

  Widget getPercentageIcon(double p) {
    if (p >= 75) return Icon(Icons.check_circle, color: Colors.green, size: 24);
    if (p >= 60) return Icon(Icons.warning, color: Colors.orange, size: 24);
    return Icon(Icons.error, color: Colors.red, size: 24);
  }

  Widget buildOverallAttendanceCard() {
    double overallPercentage = calculateOverallAttendance();
    int classesNeeded = getClassesNeededFor75();
    int totalAttended = subjects.fold(0, (sum, s) => sum + s.attended);
    int totalClasses = subjects.fold(0, (sum, s) => sum + s.total);

    return Card(
      elevation: 8,
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: overallPercentage >= 75
                ? [Colors.green.shade400, Colors.green.shade600]
                : overallPercentage >= 60
                ? [Colors.orange.shade400, Colors.orange.shade600]
                : [Colors.red.shade400, Colors.red.shade600],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Overall Attendance',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 120,
                  height: 120,
                  child: CircularProgressIndicator(
                    value: totalClasses > 0 ? overallPercentage / 100 : 0,
                    strokeWidth: 8,
                    backgroundColor: Colors.white.withOpacity(0.3),
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                ),
                Column(
                  children: [
                    Text(
                      '${overallPercentage.toStringAsFixed(1)}%',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '$totalAttended/$totalClasses',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 16),
            if (totalClasses > 0) ...[
              if (overallPercentage >= 75)
                Column(
                  children: [
                    Icon(Icons.check_circle, color: Colors.white, size: 24),
                    SizedBox(height: 8),
                    Text(
                      'Excellent!\nAbove 75%',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                )
              else
                Column(
                  children: [
                    Icon(Icons.trending_up, color: Colors.white, size: 24),
                    SizedBox(height: 8),
                    Text(
                      'Need $classesNeeded more\nclasses for 75%',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
            ] else
              Column(
                children: [
                  Icon(Icons.school, color: Colors.white, size: 24),
                  SizedBox(height: 8),
                  Text(
                    'Start marking\nattendance!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isWideScreen = MediaQuery.of(context).size.width > 800;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'CMR Attendance Tracker',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.add_circle_outline),
            onPressed: addSubject,
            tooltip: 'Add Subject',
          ),
          IconButton(
            icon: Icon(Icons.refresh_rounded),
            onPressed: resetData,
            tooltip: 'Reset All Data',
          ),
          SizedBox(width: 8),
        ],
      ),
      body: subjects.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.school_outlined,
                    size: 100,
                    color: Colors.grey[400],
                  ),
                  SizedBox(height: 24),
                  Text(
                    'No subjects added yet',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Add your first subject to start tracking attendance',
                    style: TextStyle(fontSize: 16, color: Colors.grey[500]),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 32),
                  FilledButton.icon(
                    onPressed: addSubject,
                    icon: Icon(Icons.add),
                    label: Text('Add First Subject'),
                    style: FilledButton.styleFrom(
                      padding: EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                  ),
                ],
              ),
            )
          : isWideScreen
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Left side - Overall Attendance Card
                Container(width: 350, child: buildOverallAttendanceCard()),
                // Right side - Subject List
                Expanded(
                  child: Container(
                    padding: EdgeInsets.only(right: 16, top: 16, bottom: 16),
                    child: buildSubjectList(),
                  ),
                ),
              ],
            )
          : Column(
              children: [
                // Top - Overall Attendance Card (mobile)
                Container(height: 280, child: buildOverallAttendanceCard()),
                // Bottom - Subject List
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: buildSubjectList(),
                  ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addSubject,
        tooltip: 'Add Subject',
        icon: Icon(Icons.add),
        label: Text('Add Subject'),
      ),
    );
  }

  Widget buildSubjectList() {
    return ListView.builder(
      itemCount: subjects.length,
      itemBuilder: (context, index) {
        var s = subjects[index];
        double percent = calculatePercentage(s);
        return Card(
          elevation: 2,
          margin: EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: ExpansionTile(
            leading: Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: getPercentageColor(percent).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: getPercentageIcon(percent),
            ),
            title: Text(
              s.name,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            subtitle: Padding(
              padding: EdgeInsets.only(top: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Code: ${s.code}',
                    style: TextStyle(color: Colors.grey[600], fontSize: 13),
                  ),
                  SizedBox(height: 2),
                  Row(
                    children: [
                      Text(
                        '${s.attended}/${s.total} classes',
                        style: TextStyle(color: Colors.grey[700], fontSize: 13),
                      ),
                      SizedBox(width: 8),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: getPercentageColor(percent).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${percent.toStringAsFixed(1)}%',
                          style: TextStyle(
                            color: getPercentageColor(percent),
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            children: [
              Container(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.person, size: 16, color: Colors.grey[600]),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Faculty: ${s.faculty}',
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.grey[700],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () => markAttendance(index, true),
                            icon: Icon(Icons.check, size: 18),
                            label: Text('Present'),
                            style: FilledButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: () => markAttendance(index, false),
                            icon: Icon(Icons.close, size: 18),
                            label: Text('Absent'),
                            style: FilledButton.styleFrom(
                              backgroundColor: Colors.red,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        SizedBox(width: 12),
                        IconButton(
                          onPressed: () => deleteSubject(index),
                          icon: Icon(Icons.delete_outline),
                          style: IconButton.styleFrom(
                            backgroundColor: Colors.grey[100],
                            foregroundColor: Colors.grey[600],
                          ),
                          tooltip: 'Delete Subject',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

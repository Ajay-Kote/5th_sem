// import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:attendance_tracker/main.dart';

void main() {
  testWidgets('Basic smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    // Wait for frames if async widgets are used
    await tester.pumpAndSettle();

    expect(find.text('CMR Technical Campus Attendance Tracker'), findsOneWidget);
    expect(find.text('Mathematics'), findsOneWidget);
  });
}
